﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Lab6
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Employee> emp = new List<Employee>() { new Employee { empId = 1001,Fname= "Jaya",Lname= "Gudla",title= "Analyst",dob= Convert.ToDateTime("3/02/2011"),doj=Convert.ToDateTime("02/04/2013"),city="mumbai"} ,
            new Employee { empId = 1002, Fname = "Sumit", Lname = "Gudla", title = "Associate", dob = Convert.ToDateTime("3/02/2011"), doj = Convert.ToDateTime("02/04/2013"), city = "mumbai" },
            new Employee { empId = 1003, Fname = "Malcolm", Lname = "Gudla", title = "Consultant", dob = Convert.ToDateTime("3/02/2011"), doj = Convert.ToDateTime("02/04/2013"), city = "mumbai" },
            new Employee { empId = 1004, Fname = "Madhavi", Lname = "Gudla", title = "AsstManager", dob = Convert.ToDateTime("3/02/2011"), doj = Convert.ToDateTime("02/04/2013"), city = "mumbai" },
            new Employee { empId = 1005, Fname = "Saba", Lname = "Gudla", title = "Associate", dob = Convert.ToDateTime("3/02/2011"), doj = Convert.ToDateTime("02/04/2013"), city = "mumbai" },
            new Employee { empId = 1006, Fname = "Nazia", Lname = "Gudla", title = "Consultant", dob = Convert.ToDateTime("3/02/2011"), doj = Convert.ToDateTime("02/04/2013"), city = "mumbai" },
            new Employee { empId = 1007, Fname = "Amit", Lname = "Gudla", title = "AsstManager", dob = Convert.ToDateTime("3/02/2011"), doj = Convert.ToDateTime("02/04/2013"), city = "mumbai" },
            new Employee { empId = 1008, Fname = "Vijay", Lname = "Gudla", title = "Associate", dob = Convert.ToDateTime("3/02/2011"), doj = Convert.ToDateTime("02/04/2013"), city = "mumbai" } ,
            new Employee { empId = 1009, Fname = "Rahul", Lname = "Gudla", title = "Analyst", dob = Convert.ToDateTime("3/02/2011"), doj = Convert.ToDateTime("02/04/2013"), city = "mumbai" },
            new Employee { empId = 1010, Fname = "Suresh", Lname = "Gudla", title = "Associate", dob = Convert.ToDateTime("3/02/2011"), doj = Convert.ToDateTime("02/04/2013"), city = "mumbai" }};

            Console.WriteLine("=================================================================================");
            Console.WriteLine("Display details of all the employee: ");
            Console.WriteLine("1111111111111111111111111111111111111111111111111111111111");

            var query1 = emp.OrderBy(s => s.empId);
            foreach(Employee d in query1)
            {
                Console.WriteLine("===========================================");
                Console.WriteLine("Employee id {0}: ", d.empId);
                Console.WriteLine("Employee name {0}: ", d.Fname);
                Console.WriteLine("surname {0}: ", d.Lname);
                Console.WriteLine(" title {0}: ", d.title);
                Console.WriteLine(" date of birth {0}: ", d.dob);
                Console.WriteLine("date of joining {0}: ", d.doj);
                Console.WriteLine("city {0}: ", d.city);
            }
            Console.ReadLine();
            Console.WriteLine("22222222222222222222222222222222222222222222222222222222222222");
            
            Console.WriteLine("Display details of all the employee whose location is not Mumbai");
            var query2 = from s in emp
                         where s.city != "Mumbai"
                         select s.Fname;
            foreach (string c in query2)
            {
                Console.WriteLine(c);
                
            }
            Console.ReadLine();
            Console.WriteLine("33333333333333333333333333333333333333333333333333333333333333");
            Console.WriteLine("Display details of all the employee whose title is AsstManager");
            var query3 = from s in emp
                         where s.title == "AsstManager"
                         select s;
            foreach (Employee c in query3)
            {
                Console.WriteLine("===========================================");
                Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}",c.empId,c.Fname,c.Lname,c.title);
            }
            Console.ReadLine();
            Console.WriteLine("44444444444444444444444444444444444444444444444444444444444444");
            Console.WriteLine("Display details of all the employee whose Last Name start with S");

            var query4 = from s in emp
                         where s.Lname.StartsWith("S")
                         select s.Lname;
            foreach (string c in query4)
            {
                Console.WriteLine("===============================");
                Console.WriteLine(c);
            }
            Console.ReadLine();

            //5. Display a list of all the employee who have joined before 1/1/2015 
            Console.WriteLine("5555555555555555555555555555555555555555555555555555555555555555555555555");
            Console.WriteLine("Display details of all the employee who have joined before 1/1/2015 ");
             var query5 = emp.Where(e => e.doj <= Convert.ToDateTime("1/1/2015"));         
             foreach (Employee e in query5)
             {
                Console.WriteLine("===============================");
                Console.WriteLine("EmployeeId: {0}\n FirstName: {1}\n LastName:{2}\n Title: {3}\n DOB: {4}\tDOJ: {5}\n City:{6}", e.empId, e.Fname,
                     e.Lname, e.title, e.dob, e.doj, e.city);
                 Console.ReadLine();
             }
            Console.WriteLine("6666666666666666666666666666666666666666666666666666666666666666666666666666");
            //6. Display a list of all the employee whose date of birth is after 1/1/1990
            Console.WriteLine("Display details of all the employee whose date of birth is after 1/1/1990 ");
             var query6 = emp.Where(e => e.dob >= Convert.ToDateTime("1/1/1990"));
             foreach (Employee e in query6)
             {
                Console.WriteLine("===============================");
                Console.WriteLine("EmployeeId: {0}\n FirstName: {1}\n LastName:{2}\n Title: {3}\n DOB: {4}\tDOJ: {5}\n City:{6}", e.empId, e.Fname,
                     e.Lname, e.title, e.dob, e.doj, e.city);
                 Console.ReadLine();
             }

            Console.WriteLine("7777777777777777777777777777777777777777777777777777777777777777777777777777");

            //7. Display a list of all the employee whose designation is Consultant and Associate

            Console.WriteLine("Display details of all the employee whose designation is Consultant and Associate");

             var query7 = from s in emp
                          where s.title == "Consultant" || s.title == "Associate"
                          select s.Fname;
             foreach (string c in query7)
             {
                 Console.WriteLine(c);
                 Console.ReadLine();
             }
            //8. Display total number of employees
            Console.WriteLine("8888888888888888888888888888888888888888888888888888888888888888888888888888");
            int results = emp.Count();
             Console.WriteLine("Total number of employees: {0}", results);
             Console.ReadLine();

            //9. Display total number of employees belonging to “Chennai"
            Console.WriteLine("9999999999999999999999999999999999999999999999999999999999999999999999999999");
            int results1 = emp.Count(s => s.city == "Chennai");
             Console.WriteLine("Total number of employees in Chennai: {0}", results1);
             Console.ReadLine();

            // 10. Display highest employee id from the list
            Console.WriteLine("10-------10-------10------10------10--------10-------10-------10-------10--------10");

            var query10 = (from c in emp
                            where c.empId != 0
                           select c).Max(c => c.empId);                     
             Console.WriteLine("Total number of employees: {0}", results);                      
             int id = emp.Select(i => i.empId).Max();
             Console.WriteLine("Highest employeeID of employees: {0}", id);
             Console.ReadLine();
            Console.WriteLine("11---------------11------------------11-------------------11-------------------11");

            //11. Display total number of employee who have joined after 1/1/2015           
            Console.WriteLine("Display total number of the employee who have joined after 1/1/2015 ");
             var query11 = emp.Where(e => e.doj >= Convert.ToDateTime("1/1/2015")).Count();
             Console.WriteLine(" Total number of the employee who have joined after 1/1/2015: {0}", query11.ToString());
             Console.ReadLine();
            Console.WriteLine("12---------------12-----------------12--------------------12------------------12");

            //12. Display total number of employee whose designation is not “Associate”
            Console.WriteLine("Display details of all the employee whose location is not Mumbai");
             int count = emp.Where(i => i.title != Convert.ToString("Associate")).Count();
             Console.WriteLine(" Total number of the employee who are not Associate: {0}", count);
             Console.ReadLine();
            Console.WriteLine("13---------------13------------------13------------------13------------------13");

            //13. Display total number of employee based on City

            Console.WriteLine(" Total number of the employee in particular city: {0}\t {1}" );
             Console.ReadLine();


             //14.  Display total number of employee based on city and title


           // 15. Display total number of employee who is youngest in the list
        }

        public class Employee

        {
            private int _EmployeeId;
           private string _FirstName;
           private string _LastName;
            private string _Title;
            private DateTime _Dob;
            private DateTime _Doj;
            private string _City;
            public int empId
            {
                get { return _EmployeeId; }
                set { _EmployeeId = value; }
            }
            public string Fname
            {
                get { return _FirstName; }
                set { _FirstName = value; }
            }
            public string Lname
            {
                get { return _LastName; }
                set { _LastName = value; }
            }
            public string title
            {
                get { return _Title; }
                set { _Title = value; }
            }
            public DateTime dob
            {
               get { return _Dob; }
               set { _Dob = value; }
            }
           public DateTime doj
            {
                get { return _Doj; }
                set { _Doj = value; }
            }
            public string city
            {
                get { return _City; }
                set { _City = value; }
            }

        }

    }
}
/*
 * 1001 Malcolm Daruwalla Manager 16/11/1984 8/6/2011 Mumbai
1002 Asdin Dhalla AsstManager 20/08/1984 7/7/2012 Mumbai
1003 Madhavi Oza Consultant 14/11/1987 12/4/2015 Pune
1004 Saba Shaikh SE 3/6/1990 2/2/2016 Pune
1005 Nazia Shaikh SE 8/3/1991 2/2/2016 Mumbai
1006 Amit Pathak Consultant 7/11/1989 8/8/2014 Chennai
1007 Vijay Natrajan Consultant 2/12/1989 1/6/2015 Mumbai
1008 Rahul Dubey Associate 11/11/1993 6/11/2014 Chennai
1009 Suresh Mistry Associate 12/8/1992 3/12/2014 Chennai
1010 Sumit Shah Manager 12/4/1991 2/1/2016 Pune */
