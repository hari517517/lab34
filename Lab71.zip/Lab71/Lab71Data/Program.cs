﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab71Data
{
    class Program
    {
        static void Main(string[] args)
        {
            Training_23Jan19_MumbaiEntities musicEntities = new Training_23Jan19_MumbaiEntities();
            var albums = musicEntities.Album_172312;


            Album_172312 album = new Album_172312()
            {
                Name = "Jayasree",
                Genre = "Rock",
                Year = DateTime.Parse("12/12/2018"),
                Price = 400
            };
            musicEntities.Album_172312.Add(album);
            musicEntities.SaveChanges();
            Console.WriteLine("Album Added successfully..");

            foreach (Album_172312 a in albums)
            {
                Console.WriteLine(a.AlbumId + "\t" + a.Name + "\t" + a.Genre + "\t" + a.Price + ".");
            }
            Console.ReadLine();
        }
    }
}
