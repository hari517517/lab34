﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab7Code
{
    class Program
    {
        static void Main(string[] args)
        {
            ProductContext pContext = new ProductContext();
            Product p1 = new Product() { ProductId = 1001, Name = "Barbie doll", Category = "Toys", Price = 199.99M };
            Product p2 = new Product() { ProductId = 1002, Name = "Montex Pen", Category = "Stationary", Price = 10.59M };
            pContext.Products.Add(p1);
            pContext.Products.Add(p2);
            pContext.SaveChanges();
            Console.WriteLine("Product Details Are AAadded Successfully..");
            Console.ReadLine();
        }
    }
}
