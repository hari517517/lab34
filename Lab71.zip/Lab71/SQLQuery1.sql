CREATE TABLE Album_172312
(
AlbumID INT NOT NULL,
Name varchar(20),
Genre varchar (20),
Year dATE,
Price int

)
insert into  Album_172312 values (0,'farida','rock','09/09/2019',500)
select* from  Album_172312 
