﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQEFConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Training_Cloud_VikholiEntities context = new Training_Cloud_VikholiEntities();
            var query = from staff in context.Staff_Master
                        where staff.Salary > 30000
                        select staff;
            Console.ReadLine();
            Console.WriteLine("Display the list of student which includes Student name, department and date of birth");
            foreach (Staff_Master s in query)
            {
                Console.WriteLine("Staff Code = {0},Name = {1},Salary = {2}", s.Staff_Code, s.Staff_Name, s.Salary);
            }
            Console.ReadLine();
            Console.WriteLine("=================================================================");


            Console.WriteLine("Display the list of student where city is not null");

            var query1 = from stud in context.Student_master
                        where stud.Address != null
                         select stud;
            foreach (Student_master s in query1)
            {
                Console.WriteLine("Staff City = {0} Student Name = {1}", s.Address, s.Stud_Name);
            }
            Console.ReadLine();
            Console.WriteLine("=================================================================");

            Console.WriteLine("Display the list of student which includes Student name, department and date of birth");
            var query2 = from stud in context.Student_master 
                         //where stud.Address != null
                         select stud ;
            foreach (Student_master s in query2)
            {
                Console.WriteLine("Staff Name = {0}, student Department= {1}, Student Date ofBirth {2}. ", s.Stud_Name,s.Dept_Code,s.Stud_Dob);
            }
            Console.ReadLine();
            Console.WriteLine("=================================================================");
            Console.WriteLine("Display count of total student belonging to Bangalore");
            var query3 = (from stud in context.Student_master
                             where stud.Address == "Banglore"
                         select stud).Count();
            Console.WriteLine("Count: " + query3.ToString());
            //foreach (Student_master s in query3)
            //{
            //    Console.WriteLine("No of Students belongs to Banglore {0}. ", query3.Count());
            //}
            Console.ReadLine();
            Console.WriteLine("=================================================================");
            Console.WriteLine("Display list of employees whose salary is more than the average salary of the employee.");
            //var query4 = (from staff in context.Staff_Master
            //              //where staff.Salary "
            //              select staff.Salary).Average();
            //Console.WriteLine("Average: " + query4.ToString());

            //var query5 = (from staff in context.Staff_Master where staff.Salary < query4 select staff);
            //Console.WriteLine("Salary of staff whose salary is more than Average salary of the employee: {0}" + query5.ToString());
            //Console.ReadLine();
            var query4 = (from staff in context.Staff_Master
                              //where staff.Salary "
                          select staff.Salary).Average();
            Console.WriteLine("Average: " + query4/*.ToString()*/);
           

            var query5 = (from staff in context.Staff_Master where staff.Salary > query4 select staff);
            foreach (Staff_Master s in query5)
            {
                Console.WriteLine(" employees whose salary is more than the average salary of the employee {0}, {1},{2}. ", s.Staff_Code, s.Staff_Name, s.Salary);
            }
            Console.ReadLine();







        }
    }
}
